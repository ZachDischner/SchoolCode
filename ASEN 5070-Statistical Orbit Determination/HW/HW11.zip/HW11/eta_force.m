function X = eta_force(x)
a1 = 0.98189; b1 = 0.62738; c1 = -0.097895; 
X =  a1*sin(b1*x+c1);